import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { PutCommand, DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const TABLE_NAME = "Users";
const JWT_SECRET = process.env.JWT_SECRET;

const client = new DynamoDBClient({ region: "ap-southeast-2" });
const docClient = DynamoDBDocumentClient.from(client);

export const handler = async (event) => {
  const body = JSON.parse(event.body);
  const { username, password } = body;
  console.log("here", username, password);

  // Generate salt and hash the password
  const salt = bcrypt.genSaltSync(10);
  const passwordHash = bcrypt.hashSync(password, salt);

  console.log(username, passwordHash);

  const params = {
    TableName: TABLE_NAME,
    Item: {
      PK: username,
      SK: "123",
      passwordHash: passwordHash,
    },
  };
  console.log(params);
  try {
    const response = await docClient.send(new PutCommand(params));
    console.log(response, "response");
    const token = jwt.sign({ username }, JWT_SECRET, { expiresIn: "1h" });
    console.log(token, "token");
    return {
      statusCode: 201,
      headers: {
        "Set-Cookie": `token=${token}; HttpOnly; Secure; SameSite=Strict; Max-Age=3600`, // 1 hour expiration
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ message: "User created successfully" }),
    };
  } catch (error) {
    console.log(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Could not create user" }),
    };
  }
};
